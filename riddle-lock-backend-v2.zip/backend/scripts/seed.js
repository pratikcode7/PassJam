// Adds sample leaderboard rows so the board isn't empty during a demo.
// Usage: npm run seed
const crypto = require('crypto');
const config = require('../config');
const { openDb } = require('../db');
const { computeScore } = require('../services/scoring');

const SAMPLES = [
  { nickname: 'VaultBreaker', seconds: 74, hints: 0, mode: 'random' },
  { nickname: 'Riddler', seconds: 96, hints: 1, mode: 'daily' },
  { nickname: 'PuneCoder', seconds: 128, hints: 0, mode: 'random' },
  { nickname: 'SneakyLock', seconds: 151, hints: 2, mode: 'daily' },
  { nickname: 'NightOwl', seconds: 210, hints: 1, mode: 'random' },
  { nickname: 'Tumbler', seconds: 275, hints: 3, mode: 'random' },
  { nickname: 'Hackathon', seconds: 330, hints: 2, mode: 'daily' },
  { nickname: 'SlowAndSure', seconds: 410, hints: 4, mode: 'random' },
];

const db = openDb(config.dbPath);
const insert = db.prepare(
  `INSERT INTO games (id, seed, mode, play_date, started_at, solved_at, finished_at, duration_ms,
                      revealed, mutated, hints_used, validations, score, nickname, status)
   VALUES (@id, @seed, @mode, @playDate, @startedAt, @solvedAt, @finishedAt, @durationMs,
           8, 1, @hints, 0, @score, @nickname, 'finished')`
);

const now = Date.now();
const playDate = new Date(now).toISOString().slice(0, 10);

db.transaction(() => {
  for (const s of SAMPLES) {
    const durationMs = s.seconds * 1000;
    const { score } = computeScore({ elapsedMs: durationMs, hintsUsed: s.hints });
    insert.run({
      id: `seed-${crypto.randomUUID()}`,
      seed: s.mode === 'daily' ? `daily-${playDate}` : crypto.randomBytes(4).toString('hex'),
      mode: s.mode,
      playDate,
      startedAt: now - durationMs - 5000,
      solvedAt: now - 5000,
      finishedAt: now,
      durationMs,
      hints: s.hints,
      score,
      nickname: s.nickname,
    });
  }
})();

console.log(`Seeded ${SAMPLES.length} leaderboard rows into ${config.dbPath}`);
db.close();
