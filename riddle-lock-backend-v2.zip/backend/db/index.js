const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

// NOTE: there is intentionally no column anywhere that could hold a password.
const SCHEMA = `
CREATE TABLE IF NOT EXISTS games (
  id          TEXT PRIMARY KEY,
  seed        TEXT NOT NULL,
  mode        TEXT NOT NULL DEFAULT 'random' CHECK (mode IN ('random','daily')),
  play_date   TEXT NOT NULL,
  started_at  INTEGER NOT NULL,
  solved_at   INTEGER,
  finished_at INTEGER,
  duration_ms INTEGER,
  revealed    INTEGER NOT NULL DEFAULT 1,
  mutated     INTEGER NOT NULL DEFAULT 0,
  hints_used  INTEGER NOT NULL DEFAULT 0,
  validations INTEGER NOT NULL DEFAULT 0,
  score       INTEGER,
  nickname    TEXT,
  status      TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','solved','finished'))
);

CREATE TABLE IF NOT EXISTS game_hints (
  game_id TEXT NOT NULL REFERENCES games(id) ON DELETE CASCADE,
  rule_id TEXT NOT NULL,
  PRIMARY KEY (game_id, rule_id)
);

CREATE INDEX IF NOT EXISTS idx_games_leaderboard ON games (status, score DESC, duration_ms ASC);
`;

function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new Database(file);
  if (file !== ':memory:') db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);
  return db;
}

module.exports = { openDb };
