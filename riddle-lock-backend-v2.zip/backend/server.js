const config = require('./config');
const { openDb } = require('./db');
const { createApp } = require('./app');

const db = openDb(config.dbPath);
const app = createApp({ db });

const removed = app.locals.service.purgeStale();
if (removed) console.log(`Purged ${removed} abandoned game(s).`);
setInterval(() => app.locals.service.purgeStale(), 30 * 60 * 1000).unref();

const server = app.listen(config.port, () => {
  console.log(`Riddle Lock backend listening on http://localhost:${config.port}`);
});

const shutdown = () => server.close(() => { db.close(); process.exit(0); });
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
